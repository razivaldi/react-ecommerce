import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Navbar, Sidebar, Footer, Contact } from './components'
import {
  Home,
  SingleProduct,
  Cart,
  Checkout,
  Error,
  About,
  Products,
  PrivateRoute,
  AuthWrapper,
} from './pages'

import Login from './pages/Login'
import SingleProductPage from './pages/SingleProductPage'
function App() {
  return (
    <AuthWrapper>
      <Router>
        <Navbar />
        <Sidebar />
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='singleproduct' element={<SingleProduct/>}/>
          <Route path='products/*' element={<Products/>}/>
          <Route path='products/:id' element={<SingleProductPage/>}/>
          <Route path='about' element={<About/>}/>
          <Route path='contact' element={<Contact/>}/>
          <Route path='cart' element={<Cart/>}/>
          <Route path='checkout' element={
            <PrivateRoute>
              <Checkout/>
            </PrivateRoute>
          } />
          
          {/* 
          TODO :
          Route to 
          About,Login, Cart, 
          Products, SingleProduct, 
          Checkout */}
          <Route path='error' element={<Error />} />
        </Routes>
        <Footer />
      </Router>
    </AuthWrapper>
  )
}

export default App
