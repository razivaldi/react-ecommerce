import React from 'react'
import Product from './Product'
import './gridview.css'

const GridView = ({ products }) => {
  
  return (
    <div>
      {products.map((product) => {
        return <Product key={product.id} {...product} />
      })}
    </div>
  )
}

export default GridView
