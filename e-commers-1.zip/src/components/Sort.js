import React from 'react'
import { useFilterContext } from '../context/filter_context'
import { BsFillGridFill, BsList } from 'react-icons/bs'
import './sort.css'

const Sort = () => {
  
  const { filtered_products: products, 
    setGridView,
    setListView,
    updateSort,
    sort,
    grid_view } 
    = useFilterContext()

  return (
    <div className='section-sort'>
      
    </div>
  )
}


export default Sort
