
  

const user_reducer = (state, action) => {

    if (action.type === 'USER_LOGIN_REQUEST') {
        //TODO
    }

    if (action.type === 'USER_LOGIN_SUCCESS') {

        //TODO
    }

    if (action.type === 'USER_LOGIN_FAIL') {
        
        //TODO
    }


    if (action.type === 'USER_LOGOUT') {
        
        //TODO
    }

    if (action.type === 'USER_REGISTER_REQUEST') {
        //TODO
    }
    if (action.type === 'USER_REGISTER_FAIL') {
        //TODO
    }
    if (action.type === 'USER_REGISTER_SUCCESS') {
        //TODO
    }
    
    
}

export default user_reducer
  